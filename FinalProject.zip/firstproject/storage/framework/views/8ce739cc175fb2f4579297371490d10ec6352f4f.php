<html>
<a href = " <?php echo route('nextpage') ?> "> Go to nextpage.... </a>
</html>