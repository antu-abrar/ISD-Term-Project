<html>
	<head>
		<title> <?php echo "EVENT HIVE" ?> </title>
		<base href = "contactUS.php" />
		<link href = "contactUS.css" rel = "stylesheet" />
	</head>
	
	<body>
		<header> 
			<div class = "container">
				<img src = "img/event_hive3.png" > </img>
			</div>
			<div class = "logout">
				Home | Logged in as Mumina | Logout
			</div>
		</header>
		
		<header style = "height:40px; background: linear-gradient(#C0C0C0, #FFFFFF, #C0C0C0);word-spacing: 100px;" > 
			<input type = "submit" value = "Information">
			<input type = "submit" value = "Booking">
			<input type = "submit" value = "Packages">
			<input type = "submit" value = "Reviews">
			<input type = "submit" value = "Contact us">
		</header>
		
		<main>

			<br><br>
			<div class = "Contact Us">
				<h2> Contact Us: </h2>

				<br><br>
				<h2> Email: </h2>
				EventHive@gmail.com
				<br><br>
				<h2> Mobile: </h2>
				01710123456
				<br><br>
				<h2> Location: </h2>
				<br>
				34/3 , Lake Circus Road, Dhanmondi, Dhaka 


			</div>
			<div class = "map">
				<img src = "img/map.jpg" > </img>
			</div>
		</main>
	</body>
</html>

